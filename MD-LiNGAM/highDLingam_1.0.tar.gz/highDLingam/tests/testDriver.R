library(highDLingam)
library(doParallel)


source("~/highDL/single_vs_multi.R")
source("~/highDL/highD.R")
